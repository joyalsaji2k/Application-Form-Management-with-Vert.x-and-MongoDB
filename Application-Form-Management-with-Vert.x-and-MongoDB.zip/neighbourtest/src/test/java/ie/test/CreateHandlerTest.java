package ie.test;

import static org.junit.jupiter.api.Assertions.*;

class CreateHandlerTest {

    @org.junit.jupiter.api.Test
    void handle() {
    }
}